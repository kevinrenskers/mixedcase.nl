/*:
 Working on a new network library that is inspired by [Malibu](https://github.com/vadymmarkov/Malibu),
 [CodyFire](https://github.com/MihaelIsaev/CodyFire) and [Moya](https://github.com/Moya/Moya).

 The idea is that you can define one or more enums of endpoints (very much like Moya and also like Malibu),
 everything uses Codable (like CodyFire), and responses are given via Promises (like Malibu).

 The reason to start a new library over these existing ones:

 - CodyFire is quite nice to work with, but lacks global error handling and configurable JSON
   encoding/decoding strategies.
 - Malibu has the enums of endpoints and uses promises, but has many stringly typed inputs, and the
   output is not automatically decoded into typed models.
 - Moya I just don't really enjoy working with. Instead of giving the path, method, params, headers etc etc
   for every single endpoints, as separate things, I just want to do that all at once. It also doesn't use
   promises and the syntax to work with Codable objects is pretty bad.

 I also don't really want to rely on AlamoFire if I can help it.
*/

import Foundation

// To enable debugging the SSL requests via Charles. Should not be part of an actual networking library in the future :)
public class NetworkEnabler: NSObject, URLSessionDelegate {
  public func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
    completionHandler(.useCredential, URLCredential(trust: challenge.protectionSpace.serverTrust!))
  }
}

// MARK: Library
// --------------------------------------------------------------------------------------

public struct Nothing: Decodable {}

public enum DecodeError: Error {
  case noBaseURL
  case couldNotDecode
}

protocol EndpointCollection {
  var baseURL: String? { get }
  var request: Request { get }
}

extension EndpointCollection {
  var baseURL: String? {
    return nil
  }
}

public enum Method: String {
  case get = "GET"
  case post = "POST"
  case delete = "DELETE"
}

public protocol PayloadProtocol: Encodable {}
public protocol MultipartPayload: PayloadProtocol {}
public protocol JSONPayload: PayloadProtocol {}
public protocol FormURLEncodedPayload: PayloadProtocol {}

class Networking<EndpointCollectionType: EndpointCollection> {
  private let session: URLSession
  private let decoder: JSONDecoder
  private let baseURL: String?

  init(baseURL: String? = nil, sessionConfiguration: URLSessionConfiguration = .default, decoder: JSONDecoder = JSONDecoder()) {
    self.baseURL = baseURL
    let enabler = NetworkEnabler() // TODO: remove when Charles debugging is no longer needed
    self.session = URLSession(configuration: sessionConfiguration, delegate: enabler, delegateQueue: nil)
    self.decoder = decoder
  }

  func request(_ requestConvertible: EndpointCollectionType) -> Promise<Todo> {
    let promise = Promise<Todo>()

    guard let baseURL = requestConvertible.baseURL ?? self.baseURL else {
      print("No baseURL! Either set it on Networking or on your EndpointCollection")
      promise.reject(DecodeError.noBaseURL)
      return promise
    }

    let urlString = "\(baseURL)/\(requestConvertible.request.path)"
    let url = URL(string: urlString)! // TODO

    var request = URLRequest(url: url)
    request.httpMethod = requestConvertible.request.method.rawValue

    for (key, value) in requestConvertible.request.headers {
      request.setValue(value, forHTTPHeaderField: key)
    }

    if let payload = requestConvertible.request.payload, requestConvertible.request.method == .post {
      request.httpBody = payload
    }

    let task = session.dataTask(with: request) { [weak self] data, _, error in
      if let error = error {
        promise.reject(error)
      } else if let data = data {
        do {
          if let decoded = try self?.decoder.decode(Todo.self, from: data) {
            promise.resolve(decoded)
          }
        } catch {
          promise.reject(DecodeError.couldNotDecode)
        }
      }
    }

    task.resume()

    return promise
  }
}

class Request {
  let path: String
  let method: Method
  var payload: Data?
  var headers = [String: String]()

  init(path: String, method: Method) {
    self.path = path
    self.method = method
  }

  static func get(_ path: String, decodeTo: Decodable.Type) -> Request {
    return Request(path: path, method: .get)
  }

  static func post(_ path: String, decodeTo: Decodable.Type) -> Request {
    return Request(path: path, method: .post)
  }

  static func post<T: PayloadProtocol>(_ path: String, payload: T, decodeTo: Decodable.Type) -> Request {
    return Request(path: path, method: .post).addPayload(payload)
  }

  static func delete(_ path: String, decodeTo: Decodable.Type) -> Request {
    return Request(path: path, method: .delete)
  }

  func addHeaders<T: Encodable>(_ payload: T) -> Request {
    // TODO
    return self
  }

  func addQuery<T: Encodable>(_ payload: T) -> Request {
    // TODO
    return self
  }

  func addPayload<T: Encodable>(_ payload: T) -> Request {
    let encoder = JSONEncoder()

    if payload is JSONPayload {
      do {
        self.payload = try encoder.encode(payload)
        headers["Content-Type"] = "application/json; charset=utf-8"
      } catch {
        print("Could not add encoded payload")
      }
    }

    if payload is FormURLEncodedPayload {
      do {
        // Encodable object -> Data -> Dictionary using JSONSerialization (yea, that is the easiest way..)
        let parametersData = try encoder.encode(payload)
        if let parameters = try JSONSerialization.jsonObject(with: parametersData, options: .allowFragments) as? [String: Any] {
          self.payload = QueryBuilder().buildQuery(from: parameters).data(using: .utf8)
          headers["Content-Type"] = "application/x-www-form-urlencoded; charset=utf-8"
        }
      } catch {
        print("Could not add encoded payload")
      }
    }

    if payload is MultipartPayload {
      // TODO
    }

    return self
  }
}


// MARK: Actually using it
// --------------------------------------------------------------------------------------

struct Todo: Codable {
  let id: Int
  let title: String
  let userId: Int?
  let completed: Bool?
}

struct CreateTodoData: JSONPayload {
  let userId: Int
  let title: String
  let completed: Bool
}

enum TodoEndpoints {
  case getAllTodos
  case getTodo(id: Int)
  case deleteTodo(id: Int)
  case createTodo(payload: CreateTodoData)
}

extension TodoEndpoints: EndpointCollection {
  var request: Request {
    switch self {
    case .getAllTodos:
      return Request.get("todos/", decodeTo: [Todo].self)

    case .getTodo(let id):
      return Request.get("todos/\(id)", decodeTo: Todo.self)

    case .deleteTodo(let id):
      return Request.delete("todos/\(id)", decodeTo: Nothing.self)

    case .createTodo(let payload):
      return Request.post("todos/", payload: payload, decodeTo: Todo.self)
    }
  }
}

let networking = Networking<TodoEndpoints>(baseURL: "https://jsonplaceholder.typicode.com")

networking.request(.getTodo(id: 1)).done { todo in
  print("todo: \(todo)")
}.fail { error in
  print(error)
}

let payload = CreateTodoData(userId: 666, title: "Hello!", completed: false)
networking.request(.createTodo(payload: payload)).done { todo in
  print("todo: \(todo)")
}.fail { error in
  print(error)
}
